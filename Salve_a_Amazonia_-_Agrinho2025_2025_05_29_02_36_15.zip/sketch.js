let palavra = "Salve as Arvores!"; //Palavra de Início do Nível 1.
let framesParaSumir = 320; // 3 segundos (60 FPS)
let somTocou = false; // Variavel pra saber se tocou Som.
let somTela2; // Som Fogo
let recordePontos = 0; // Marcador de Pontos após perder
let arvoresPlantadas = 0 //Contador de Árvores Plantadas 
let tempoPerda = 0; // Temporizador para mensagem "Você perdeu!"
let temperatura = 20; // Marcador de Temperatura
let particulas = []; // Particulas de Fogo.
let Pontos = 0;// Marcador de Pontos
let ArvoreQueimada = true; // Quantas árvores queimadas foram Salvas, mesma coisa que (arvoresplantadas)
let imagemÁrvoreQ, imagemÁrvoreS;
let ÁrvoreQ = [];//Variavel Arvore
//criando a colisão entre o Personagem e a bolinha.
function colide(x1, y1, s1, x2, y2, s2) {//colisão personagem com Bolinha
  let d = dist(x1, y1, x2, y2);
  return d < (s1 / 2 + s2 / 2);
}






//fazendo a posição aleatória
function novaPosicaoAleatoria() {
  x = random(width - z);
  y = random(height - z);
}

//reiniciando a temperatura da tela = 2
function reiniciarJogo() {
  temperatura = 20; // Reinicia a temperatura
  Pontos = 0; // Reinicia a pontuação
  ÁrvoreQ = []; // Limpa e recria as árvores queimadas
  for (let i = 0; i < 3; i++) {
    ÁrvoreQ.push({
      x: random(width - 50),
      y: random(height - 50),
      size: 50,
      queimada: true
    });
    
    
    
    
    
    
  }
  Px = 200; // Reinicia a posição do personagem
  Py = 134;
  tocou = false;
}

let tocou = false;

//variaveis de posição
let Px=200, Py=134, Pz=70;
let x = 100;
let y = 100;
let z = 20;
let coli = false, c;



let borda = 100, imagem, tela = 1;
function setup() {
  createCanvas(474, 238);
userStartAudio();
  for (let i = 0; i < 3; i++) {
    ÁrvoreQ.push({ 
      x: random(width - 50), 
      y: random(height - 50), 
      size: 50, 
      queimada: true 
    });
  
}

    for (let i = 0; i < 50; i++) {
    particulas.push({
      x: random(width),
      y: random([0, height]), // Topo ou base
      vx: random(-1, 1),
      vy: random(-2, -1),
      tamanho: random(4, 10),
      cor: color(255, random(100, 150), 0, 150)
    });
  }

   //preload img
   imagem = loadImage ('OIP.jpeg');
   imagem2 = loadImage ('avatar.png')
   imagem3 = loadImage ('OIP.png');
   imagem4 = loadImage ('OIP-licence.png');
   imagem5 = loadImage ('IMG-20240914-WA0399.jpg');
   imagem6 = loadImage ('freepik__adjust__18207.png');
   imagemÁrvoreQ = loadImage ('1747870117102.png');
   imagemÁrvoreS = loadImage ('1747869791721.png');
}for (let ÁrvoreS of ÁrvoreQ) { 
  if (ÁrvoreS.queimada && tocou) {
    ÁrvoreS.queimada = false;
    arvoresPlantadas++; // Incrementa ao recuperar uma árvore
  }
}

function verificarRestauracao() {
  let todasNormais = true;

  for (let ÁrvoreS of ÁrvoreQ) {
    if (ÁrvoreS.queimada) {
      todasNormais = false;
      break;
    }
  }

  if (todasNormais) {
    // Adicionar mais 3 árvores pegando fogo
    for (let i = 0; i < 3; i++) {
      ÁrvoreQ.push({
        x: random(width - 50),
        y: random(height - 50),
        size: 50,
        queimada: true
      });
    }
  }

}

  
  




// fontes
let minhafonte;
function preload(){
  somTela2 = loadSound('som-de-fogo-fire-sound-effect-efeito-sonoro-112953.mp3' , () => {
    console.log("Som carregado com sucesso!");
  }, () => {
    console.log("Erro ao carregar o som.");
  });
  minhafonte = loadFont('Minecrafter.Alt.ttf');
  minhafonte2 = loadFont('upheavtt.ttf');
}
for (let ÁrvoreS of ÁrvoreQ) { 
  if (ÁrvoreS.queimada && tocou) {
    ÁrvoreS.queimada = false;
    arvoresPlantadas++; // Incrementa ao recuperar uma árvore
  }
}
//verificando a vitória para mudar de tela
function verificarVitoria() {
  if (arvoresPlantadas >= 70) {
    tela = 6; // Agora a tela de vitória será a número 6
  }
}
// botoes tela de vitória
 function mousePressed() {
  if (tela == 6) {
    let textoBotao1 = "Voltar ao Menu";
    let textoBotao2 = "Reiniciar";

    let larguraBotao1 = textWidth(textoBotao1) + 20;
    let larguraBotao2 = textWidth(textoBotao2) + 20;
    let alturaBotao = 40;
    let espacoEntreBotoes = 20;
    let yBotao = height - 80;

    // Botão "Voltar ao Menu"
    if (mouseX > width / 2 - larguraBotao1 - espacoEntreBotoes / 2 &&
        mouseX < width / 2 - espacoEntreBotoes / 2 &&
        mouseY > yBotao && mouseY < yBotao + alturaBotao) {
      mudarTela(1); // Agora a tela será mudada corretamente
    }

    // Botão "Reiniciar"
    if (mouseX > width / 2 + espacoEntreBotoes / 2 &&
        mouseX < width / 2 + larguraBotao2 + espacoEntreBotoes / 2 &&
        mouseY > yBotao && mouseY < yBotao + alturaBotao) {
      mudarTela(2); // Agora o jogo será reiniciado corretamente
    }
  }
}

// reiniciando tela 2
function reiniciarTela2() {
  temperatura = 20; // Reseta a temperatura
  arvoresPlantadas = 0; // Reseta contador de árvores plantadas
  Pontos = 0; // Reinicia os pontos
  ÁrvoreQ = []; // Limpa árvores queimadas

  // Criando novas árvores queimadas
  for (let i = 0; i < 3; i++) {
    ÁrvoreQ.push({
      x: random(width - 50),
      y: random(height - 50),
      size: 50,
      queimada: true
    });
  }

  console.log("Tela 2 foi reiniciada!");
}

//mudando para nova tela 2 atualizada
function mudarTela(novaTela) {
  if (novaTela == 2) {
    reiniciarTela2(); // Reinicia a tela 2 ao entrar nela
  }

  tela = novaTela;
  console.log("Mudando para tela: " + tela);
}


function draw() {
    console.log("Tela atual: " + tela);
 
  
   if(tela == 1){
  
    background(imagem, 50);
  
      if (Pontos > recordePontos) {
    recordePontos = Pontos;
  }
  
    arvoresPlantadas = 0; 
    reiniciarJogo(); 
    
          if (tela === 2 && !somTela2.isPlaying()) {
    somTela2.play();
  }
    
somTela2.setVolume(0.1);
     
   stroke(0, 220, 0);
   fill(0, 128, 0);
  rect(205, 80, 75, 75, 20);
  image(imagem3, 205, 80, 75, 75);
  rect(315, 93, 50, 50, 20);
  image(imagem2, 313, 93, 50, 50)
  rect(120, 93, 50, 50, 20);
  image(imagem4, 120, 93, 50, 50);
   
  stroke(0, 0, 0);

  textSize(25);
  textAlign(CENTER);
  textFont(minhafonte);
  fill(220, 220, 220);
  text("Jogar", 240, 180);
  textSize(35)
  text("Salve a Amazonia", 245, 65);
  textSize(15);
  text("Personagens", 360, 175);
  text("Creditos", 140, 175);
  textSize(12);
  text("desenvolvido por Gabryel", 100, 235);
  textFont(minhafonte2);
  textSize(20);
  text("Beta 0.1", 435, 235);
    
  
  if(mouseX>=205 && mouseX<=280 && mouseY>=80 && mouseY<=155){
    noFill();
    stroke(0, 0, 0);
    rect(205, 80, 75, 75, 20);
  }
  
  if(mouseX>=315 && mouseX<=365 && mouseY>=93 && mouseY<=143){
    noFill();
    stroke(0, 0, 0);
    rect(315, 93, 50, 50, 20);
  }
  
  if(mouseX>=120 && mouseX<=170 && mouseY>=93 && mouseY<= 155){
    noFill();
    stroke(0, 0, 0);
    rect(120, 93, 50, 50, 20);
     }
  //Tela de Regras, Após o Botão "Jogar".
  if(mouseIsPressed)
   if(mouseX>=205 && mouseX<=280 && mouseY>=80 && mouseY<=155){
     tela = 2;
   }
    //Tela de Personagens.
 if(mouseIsPressed)
   if(mouseX>=315 && mouseX<=365 && mouseY>=93 && mouseY<=143){
     tela = 3;
   }
    //Tela de Créditos/Licenças.
  if(mouseIsPressed)
    if(mouseX>=120 && mouseX<=170 && mouseY>=93 && mouseY<= 155){
      tela = 4;
    }
  }
  
  
  
  
  
  //tela de vitoria
  
 else if (tela == 6) {
  background(0, 255, 0); // Fundo verde de vitória
  fill(255);
  textSize(32);
  textAlign(CENTER, CENTER);
  text("Parabéns! Você venceu!", width / 2, height / 2 - 100);

  // Configuração dos botões com tamanho baseado no texto
  textSize(20);
  let textoBotao1 = "Voltar ao Menu";
  let textoBotao2 = "Reiniciar";

  let larguraBotao1 = textWidth(textoBotao1) + 20; // Adicionando um pequeno espaço extra
  let larguraBotao2 = textWidth(textoBotao2) + 20;
  let alturaBotao = 40;
  let espacoEntreBotoes = 20;
  let yBotao = height - 80;

  fill(0, 128, 0);
  rect(width / 2 - larguraBotao1 - espacoEntreBotoes / 2, yBotao, larguraBotao1, alturaBotao, 10);
  fill(255);
  textAlign(CENTER, CENTER);
  text(textoBotao1, width / 2 - larguraBotao1 / 2 - espacoEntreBotoes / 2, yBotao + alturaBotao / 2);

  fill(0, 128, 0);
  rect(width / 2 + espacoEntreBotoes / 2, yBotao, larguraBotao2, alturaBotao, 10);
  fill(255);
  text(textoBotao2, width / 2 + larguraBotao2 / 2 + espacoEntreBotoes / 2, yBotao + alturaBotao / 2);

  // Mensagem "Mais níveis em breve" na diagonal inferior direita
  push();
  fill(0);
  textSize(18);
  textAlign(RIGHT);
  translate(width - 10, height - 10);
  rotate(-PI / 6);
  text("Mais níveis em breve", 0, 0);
  pop();
}
  

  function reiniciarJogo() {
  temperatura = 20; // Reinicia a temperatura
  arvoresPlantadas = 0; // Zera o contador de árvores plantadas
  ÁrvoreQ = []; // Limpa árvores queimadas
  for (let i = 0; i < 3; i++) {
    ÁrvoreQ.push({
      x: random(width - 50),
      y: random(height - 50),
      size: 50,
      queimada: true
    });
  }
}

  
  
  verificarVitoria(); // Chamando a função em cada quadro


  
  
  
  
  if (tela == 6) {
  background(imagem, 50); 
  fill(255);
  textSize(25);
  textAlign(CENTER, CENTER);
  text("Parabéns! Você salvou as árvores!", width / 2, height / 2);
}
  
  
  
  
  if (tela === 2 && !somTocou) {
    somTela2.play();
    somTocou = true; // Garante que o som toque apenas uma vez
  }
    if (tela === 2) {
    if (!somTela2.isPlaying()) {
      somTela2.loop(); // Faz o som tocar em loop
    }
  } else {
    somTela2.stop(); // Para o som imediatamente ao sair da tela 2
  }

  if(tela == 1){
  
    background(imagem, 50);
  
      if (Pontos > recordePontos) {
    recordePontos = Pontos;
  }
  
    arvoresPlantadas = 0; 
    reiniciarJogo(); 
    
          if (tela === 2 && !somTela2.isPlaying()) {
    somTela2.play();
  }
    
somTela2.setVolume(0.1);
     
   stroke(0, 220, 0);
   fill(0, 128, 0);
  rect(205, 80, 75, 75, 20);
  image(imagem3, 205, 80, 75, 75);
  rect(315, 93, 50, 50, 20);
  image(imagem2, 313, 93, 50, 50)
  rect(120, 93, 50, 50, 20);
  image(imagem4, 120, 93, 50, 50);
   
  stroke(0, 0, 0);

  textSize(25);
  textAlign(CENTER);
  textFont(minhafonte);
  fill(220, 220, 220);
  text("Jogar", 240, 180);
  textSize(35)
  text("Salve a Amazonia", 245, 65);
  textSize(15);
  text("Personagens", 360, 175);
  text("Creditos", 140, 175);
  textSize(12);
  text("desenvolvido por Gabryel", 100, 235);
  textFont(minhafonte2);
  textSize(20);
  text("Beta 0.1", 435, 235);
    
  
  if(mouseX>=205 && mouseX<=280 && mouseY>=80 && mouseY<=155){
    noFill();
    stroke(0, 0, 0);
    rect(205, 80, 75, 75, 20);
  }
  
  if(mouseX>=315 && mouseX<=365 && mouseY>=93 && mouseY<=143){
    noFill();
    stroke(0, 0, 0);
    rect(315, 93, 50, 50, 20);
  }
  
  if(mouseX>=120 && mouseX<=170 && mouseY>=93 && mouseY<= 155){
    noFill();
    stroke(0, 0, 0);
    rect(120, 93, 50, 50, 20);
     }
  //Tela de Regras, Após o Botão "Jogar".
  if(mouseIsPressed)
   if(mouseX>=205 && mouseX<=280 && mouseY>=80 && mouseY<=155){
     tela = 2;
   }
    //Tela de Personagens.
 if(mouseIsPressed)
   if(mouseX>=315 && mouseX<=365 && mouseY>=93 && mouseY<=143){
     tela = 3;
   }
    //Tela de Créditos/Licenças.
  if(mouseIsPressed)
    if(mouseX>=120 && mouseX<=170 && mouseY>=93 && mouseY<= 155){
      tela = 4;
    }
  }

  
//Códigos Tela 2./ Botão Jogar
   else if(tela == 2){
     
   background(imagem6, 50)
     
      for (let i = particulas.length - 1; i >= 0; i--) {
    let p = particulas[i];

    fill(p.cor);
    noStroke();
    ellipse(p.x, p.y, p.tamanho);

    // Movimento da particula fogo.
    p.x += p.vx;
    p.y += p.vy;
    p.tamanho *= 0.98; // Fogo diminui com o tempo

    // Resetar partículas quando saírem da tela
    if (p.tamanho < 2 || p.y < 0) {
      particulas[i] = {
        x: random(width),
        y: random([0, height]),
        vx: random(-1, 1),
        vy: random(-2, -1),
        tamanho: random(4, 10),
        cor: color(255, random(100, 150), 0, 150)
      };
    }
    }
     
    
     
 


     for (let ÁrvoreS of ÁrvoreQ) { 
  if (ÁrvoreS.queimada && tocou) {
    ÁrvoreS.queimada = false;
    arvoresPlantadas++; // Incrementa ao recuperar uma árvore
  }
}
     
     
     
     
   stroke(0, 0, 0);
   
   textAlign(CENTER);
     textFont(minhafonte);
   fill(220, 220, 220);
   textSize(20);
   text('Nivel 1', 234, 33);

     if (frameCount < framesParaSumir) {
    textSize(32);
    textAlign(CENTER, CENTER);
    text(palavra, width / 2, height / 2);}
  
     textFont(minhafonte2);
     textSize(20);
     text('plante as árvores para acabar com o fogo!', 240, 230);
 
      

     
          //Criando árvores e buracos de plantação    
  stroke(0, 0, 0);
  fill(240, 134, 0);
  rect(x, y, z, z, z);    
   
     
     image(imagem2, Px, Py, Pz, Pz);

     
     for (let ÁrvoreS of ÁrvoreQ) { 
  if (ÁrvoreS.queimada) {
    image(imagemÁrvoreQ, ÁrvoreS.x, ÁrvoreS.y, ÁrvoreS.size, ÁrvoreS.size);
  } else {
    image(imagemÁrvoreS, ÁrvoreS.x, ÁrvoreS.y, ÁrvoreS.size, ÁrvoreS.size);
  }
       
  


    if (tocou) {
        ÁrvoreS.queimada = false;
      }
}
 if (colide(Px, Py, Pz, x, y, z) && !tocou) {
      Pontos += 1; // Adiciona apenas 1 ponto
   temperatura -= 3;
      tocou = true;
    verificarRestauracao();
 }
        // Vê se o personagem tocou o objeto.
    if (colide(Px, Py, Pz, x, y, z)) {
      tocou = true;
      ArvoreQueimada = false;
    }
     

    // o Personagem precisa parar de precionar a tecla.
    if (!keyIsPressed && tocou) {
      novaPosicaoAleatoria();
      tocou = false; 
      
    }
     
     
      // Aumenta a temperatura .
    temperatura += 0.04;

    textSize(20);
    fill(255, 0, 0);
    text("Temperatura: " + temperatura.toFixed(1) + "°C", 107, 50);
  // Verifica se a temperatura atingiu 100°C
 if (temperatura >= 100 && tela != 5) {
  tempoPerda = millis(); // Registra o momento da derrota
  tela = 5; // Define a tela de derrota
   console.log("Mudando para tela 5...");
}
    
     fill(220);
text("Árvores Plantadas: " + arvoresPlantadas, 117, 65); 

   textSize(20);
fill(255, 215, 0); // Cor dourada para destacar
text("Recorde: " + recordePontos, width / 2, height - 20);

     
     
      textSize(20);
    fill(255);
    text("Pontos: " + Pontos, 50, 30);
 text('use setas para se mover', 130, 80);  
    text('plante 70 árvores para vencer', 240, 10);     
     
     
 if (keyIsPressed) {
  if (keyCode === ESCAPE) {
    tela = 1; // Volta para a tela inicial
  }
}

     
     
     
     
     if(keyIsPressed) {
   if (keyCode === LEFT_ARROW) {
   Px = Px - 2
  } else if (keyCode === RIGHT_ARROW) {
   Px = Px + 2
  }  if (keyCode === UP_ARROW) {
   Py = Py - 2
  } else if (keyCode === DOWN_ARROW) {
   Py = Py + 2
  }
     
     // Barreiras de final de mapa
    if(Px>450 || coli == true){
      Px = 200
      Py = 134
      coli = false;
    }
    if(Py>300 || coli == true){
      Px = 200
      Py = 134
      coli = false;
    }
    if(Px<-70 || coli == true){
       Px = 200
       Py = 134
       coli = false;      
    }  
      if(Py<-70 || coli == true){
      Px = 200
      Py = 134
      coli = false;
        
        
        
       
        
        
        
        
        
        
        
      }
     }
     
 }
  
     // Tela de derrota
  else if (tela == 5) {
    console.log('Tela Ativada');
  
    background(imagem, 50);
    textSize(40);
    fill(255, 0, 0);
  textAlign(CENTER, CENTER);
text("Você perdeu!", width / 2, height / 2);


    // Espera 3 segundos antes de voltar para a tela inicial
  if (millis() - tempoPerda > 6000) {
    tela = 1; // Retorna para tela inicial após 3 segundos
    temperatura = 20; // Reinicia a temperatura
    tempoPerda = 0; // Reseta o temporizador
        

  
  
  
}

  }
  else if(tela == 3){
    

     background (imagem, 50);
    
   stroke(0, 220, 0);
   fill(28, 28, 28);
   rect(35, 10, 400, 200, 0);
    fill(0, 128, 0);
    rect(40, 15, 55, 30, 20);
    fill(54, 54, 54);
    rect(150, 10, 300, 200, 0);
    fill('#666666');
    rect(56, 150, 70, 30, 0);

    
   // Imagem na Aba Personagem 
   image(imagem2, 150, 15, 70, 70);
   image(imagem2, 40, 50, 100, 100);
  
    
    //Botão Voltar da tela Personagem
    fill(220, 220, 220);
    textFont(minhafonte2);
    textSize(20);
    text('<-', 65, 35);
    
    // Texto "Em breve Mais..."
    textFont(minhafonte2);
    textSize(25);
    stroke(0, 128, 0);
    fill(220, 220, 220);
    text('Em breve mais...', 300, 200);
    
    // Texto "EQUIP!".
    textFont(minhafonte2);
    stroke(0, 0, 0);
    textSize(20);
    fill(220, 220, 220);
    text('EQUIP!', 93, 165);
    
    
    
    
    // comando Voltar da Tela de Personagem
     if(mouseX>=40 && mouseX<=95 && mouseY>=15 && mouseY<= 45){
    noFill();
    stroke(0, 0, 0);
    rect(40, 15, 55, 30, 20);}
    
    if(mouseIsPressed)
   if(mouseX>=40 && mouseX<=95 && mouseY>=15 && mouseY<=45){
     tela = 1;}  
   
    //Contorno do Mini personagem na Aba Personagem.
    if(mouseX>=150 && mouseX<=220 && mouseY>=15 && mouseY<=85){
    noFill();
    stroke(0, 0, 0);
    rect(160, 17, 50, 65, 0);}
    
    
    //Contorno de Clique no botão "EQUIP!". Aba Personagem.
    if(mouseX>=56 && mouseX<=126 && mouseY>=150 && mouseY<=180){
    noFill();
    stroke(0, 0, 0);
    rect(56, 150, 70, 30, 0);}   
    
    
    
       
   
   }
 
  
  
  
  
  else if (tela == 4){
    
    background(imagem, 50);
    
    //Paredão Cinza com Contorno verde. Aba Créditos.
    stroke(0, 128, 0);
    fill(28, 28, 28);
    rect(95, 0, 300, 350, 0);
    
    
    
    //Botão Voltar Tela de Créditos
    fill(0, 128, 0);
    stroke(0, 128, 0);    
    rect(40, 15, 55, 30, 20);
    fill(220, 220, 220);
    textFont(minhafonte2);
    textSize(20);
    text('<-', 65, 35);
    
    // Todas as Info na Aba Créditos.
   fill(220, 220, 220);
   stroke(0, 128, 0); 
   textFont(minhafonte); 
   textSize(22); 
   text('Gabryel Studios', 240, 30);
   stroke('#2196f3');
   textFont(minhafonte2);
   textSize(14); 
   text('Desenvolvimento do Jogo', 240, 45);
    textSize(13);
   text('Inspiração Interface : Minecraft', 240, 65);
   text('Estilo de Jogo : GabryelStudios', 239, 77);
    textSize(13);
   text('Personagens Criados em : Avatar In Pixels', 244, 89);
   text('Desenvolvedor :', 300, 130);
    textSize(19);
    textFont(minhafonte);
    text('GABRYEL IEDO1TD', 300, 160);
    image(imagem5, 100, 110, 100, 120);
    textFont(minhafonte2);
    textSize(12)
    text('Instituição: Dr.Iedo Néspolo', 300, 170);
    text('Professor: Daniel Marcos', 290, 180);
    text('Aluno:Gabryel Dos Anjos De Paula', 300, 190);   
    
    
    //Botão "<-" voltar. Aba Créditos.
    if(mouseX>= 40 && mouseX<=95 && mouseY>=15 && mouseY<=45){
      noFill();
      stroke(0, 0, 0); 
      rect(40, 15, 55, 30, 20); }
    
    if (mouseIsPressed){
      if(mouseX>= 40 && mouseX<= 95 && mouseY>= 15 && mouseY<= 45){
        tela = 1; 
         }
 
      
  
      
      
      
      
      
      
      
      
      
    } 
 



       
       
       
       
       }
}